<script src="{{ URL::asset('dist-assets/js/plugins/jquery-3.3.1.min.js') }}"></script>
<script src="{{ URL::asset('dist-assets/js/plugins/bootstrap.bundle.min.js') }}"></script>
<script src="{{ URL::asset('dist-assets/js/plugins/perfect-scrollbar.min.js') }}"></script>
<script src="{{ URL::asset('dist-assets/js/scripts/script.min.js') }}"></script>
<script src="{{ URL::asset('dist-assets/js/scripts/sidebar.horizontal.script.js') }}"></script>
<script src="{{ URL::asset('dist-assets/js/plugins/datatables.min.js') }}"></script>
<script src="{{ URL::asset('js/moment.js') }}"></script>
<script src="{{ URL::asset('plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ URL::asset('plugins/datepicker/bootstrap-datepicker.js') }}"></script>
<script src="{{ URL::asset('dist-assets/js/plugins/sweetalert2.min.js') }}"></script>
<script src="{{ URL::asset('plugins/select2/dist/js/select2.full.min.js')}}"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

{{-- <script src="{{ URL::asset('dist-assets/js/scripts/chartjs.script.min.js') }}"></script> --}}