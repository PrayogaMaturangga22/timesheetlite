<div class="app-footer" style="background-color: #10B3B6;">
    <div class="footer-bottom pt-3 d-flex flex-column flex-sm-row align-items-center">
        <p class="text-white"><strong>Timesheet Lite Data Center</strong></p>
        <span class="flex-grow-1"></span>
        <div class="d-flex align-items-center">
            <img class="logo" src="{{ URL::asset('img/logo.png') }}" alt="">
            <div>
                <p class="m-0 text-white">&copy; 2020 PT. Ganeshcom Studio</p>
                <p class="m-0 text-white">All rights reserved</p>
            </div>
        </div>
    </div>
</div>
