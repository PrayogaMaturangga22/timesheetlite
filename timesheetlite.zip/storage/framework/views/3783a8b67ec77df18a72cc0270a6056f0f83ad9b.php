<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12" style="padding-top: 15%;">
                            <div style="padding-top: 20px;">
                                <img style="display: block; margin-left: auto; margin-right: auto; width: 50px; margin-bottom: 10px;" src="<?php echo e(URL::asset('img/logo.png')); ?>" alt="" height="50px">
                                <h2 style="font-family: Century Gothic; text-align: center;"><strong>mytimesheet</strong><span style="font-size: 14px;">.id</span></h2>
                                <h2 style="text-align: center;">Data Center</h2>
                            </div>        
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12" style="padding-top: 30px;">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
        
                                <div class="form-group row">
                                    <label for="email" class="col-md-12 col-form-label"><?php echo e(__('E-Mail Address')); ?></label>
        
                                    <div class="col-md-12">
                                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
        
                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
        
                                <div class="form-group row">
                                    <label for="password" class="col-md-12 col-form-label"><?php echo e(__('Password')); ?></label>
        
                                    <div class="col-md-12">
                                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">
        
                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="captcha">Captcha</label>
                                    <?php echo NoCaptcha::renderJs(); ?>

                                    <?php echo NoCaptcha::display(); ?>

                                    <?php if($errors->first('g-recaptcha-response') != ""): ?>
                                        <span class="text-danger">Please complete captcha validation</span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
        
                                            <label class="form-check-label" for="remember">
                                                <?php echo e(__('Remember Me')); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Login')); ?>

                                        </button>
        
                                        <?php if(Route::has('password.request')): ?>
                                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                                <?php echo e(__('Forgot Your Password?')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0" style="padding-top: 20px;">
                    <div class="col-md-12">
                        <p style="text-align: center;">&copy; 2020 PT. Ganeshcom Studio</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('logintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timesheetlite\resources\views/auth/login.blade.php ENDPATH**/ ?>