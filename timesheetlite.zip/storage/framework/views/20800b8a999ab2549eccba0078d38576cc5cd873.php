<!DOCTYPE html>
<html lang="en" dir="">

<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('additionalcss'); ?>

<body class="text-left" style="background-color: #ededed;">
<?php echo $__env->yieldContent('loading-bar'); ?>
    <div class="app-admin-wrap layout-horizontal-bar">
        <?php echo $__env->make('mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('horizontalbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content-wrap d-flex flex-column" style="background-color: #ededed;">
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additionalscript'); ?>
</body>

</html>

<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldContent('scriptmodal'); ?><?php /**PATH C:\xampp\htdocs\timesheetlite\resources\views/template.blade.php ENDPATH**/ ?>