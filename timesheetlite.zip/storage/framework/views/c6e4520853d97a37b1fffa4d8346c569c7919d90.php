<!DOCTYPE html>
<html lang="en" dir="">

<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('additionalcss'); ?>

<body class="text-left" style="background-color: #10B3B6;">
<?php echo $__env->yieldContent('loading-bar'); ?>
    <div class="app-admin-wrap layout-horizontal-bar">
        <div class="main-content-wrap d-flex flex-column" style="background-color: #10B3B6;">
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('allscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additionalscript'); ?>
</body>

</html>

<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldContent('scriptmodal'); ?><?php /**PATH C:\xampp\htdocs\timesheetlite\resources\views/logintemplate.blade.php ENDPATH**/ ?>