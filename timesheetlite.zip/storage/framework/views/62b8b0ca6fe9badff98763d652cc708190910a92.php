<script src="<?php echo e(URL::asset('dist-assets/js/plugins/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('dist-assets/js/plugins/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('dist-assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('dist-assets/js/scripts/script.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('dist-assets/js/scripts/sidebar.horizontal.script.js')); ?>"></script>
<script src="<?php echo e(URL::asset('dist-assets/js/plugins/datatables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/moment.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(URL::asset('dist-assets/js/plugins/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/select2/dist/js/select2.full.min.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>

<?php /**PATH C:\xampp\htdocs\timesheetlite\resources\views/allscript.blade.php ENDPATH**/ ?>